package com.fzu.model;

import java.sql.Date;

/**
 * ��ѧ�ƻ�ӳ����
 * 
 * @author psb
 * @time 2016.6.25
 */
public class Schedule {

	private String cno;
	private String cname;
	private Date pstime;
	private Date petime;
	private Date sstime;
	private Date setime;
	private int clong;
	private int longtime;
	private String caddress;
	private String tname;

	public String getCno() {
		return cno;
	}

	public void setCno(String cno) {
		this.cno = cno;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public Date getPstime() {
		return pstime;
	}

	public void setPstime(Date pstime) {
		this.pstime = pstime;
	}

	public Date getPetime() {
		return petime;
	}

	public void setPetime(Date petime) {
		this.petime = petime;
	}

	public Date getSstime() {
		return sstime;
	}

	public void setSstime(Date sstime) {
		this.sstime = sstime;
	}

	public Date getSetime() {
		return setime;
	}

	public void setSetime(Date setime) {
		this.setime = setime;
	}

	public int getClong() {
		return clong;
	}

	public void setClong(int clong) {
		this.clong = clong;
	}

	public int getLongtime() {
		return longtime;
	}

	public void setLongtime(int longtime) {
		this.longtime = longtime;
	}

	public String getCaddress() {
		return caddress;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

}
