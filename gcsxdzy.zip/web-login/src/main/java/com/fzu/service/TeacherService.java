package com.fzu.service;

import java.util.List;

import com.fzu.model.Teacher;

/**
 * ���ܸ�Ҫ��TeacherService�ӿ���
 * 
 * @author psb
 * @time 2016.6.25
 */
public interface TeacherService {

	Teacher selectUserById(String tId);

	List<Teacher> selectall();

	Teacher register(String id, String name, String pwd, String tsex, String tphone, String tclass, String classID,
			String school);

	Teacher update(String id, String tclass);

	Teacher delete(String id);
}
