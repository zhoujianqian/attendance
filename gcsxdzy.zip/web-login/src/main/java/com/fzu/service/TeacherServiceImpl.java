package com.fzu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fzu.dao.TeacherDao;
import com.fzu.model.Teacher;

/**
 * ���ܸ�Ҫ��TeacherServiceʵ����
 * 
 * @author psb
 * @time 2016.6.25
 */
@Service
public class TeacherServiceImpl implements TeacherService {

	@Autowired
	private TeacherDao teacher;

	public Teacher selectUserById(String userId) {
		if (userId.length() > 0) {
			return teacher.selectUserById(userId);
		}
		return null;
	}

	public Teacher register(String Id, String name, String pwd, String sex, String tphone, String tclass,
			String classId, String school) {
		if (Id.length() > 0 && pwd.length() > 0 && name.length() > 0 && sex.length() > 0 && tclass.length() > 0) {
			return teacher.insert(Id, name, pwd, sex, tphone, tclass, classId, school);
		}
		return null;

	}

	public Teacher update(String Id, String classId) {
		if (Id.length() > 0 && classId.length() > 0) {
			return teacher.update(Id, classId);
		}
		return null;
	}

	public Teacher delete(String Id) {
		if (Id.length() > 0) {
			return teacher.delete(Id);
		}
		return null;
	}

	public List<Teacher> selectall() {
		// TODO Auto-generated method stub
		return teacher.selectallteacher();
	}

}
