package com.fzu.service;

import java.util.List;

import com.fzu.model.ClassInfo;

/**
 * ���ܸ�Ҫ��ClassInfo�ӿ���
 * 
 * @author psb
 * @time 2016.6.25
 */
public interface ClassInfoService {

	ClassInfo selectById(String classId);

	List<ClassInfo> selectall();

	void insert(String classId, String cname, int classcap, String school, String college, String department,
			String profession);

}
