package com.fzu.service;

public interface KaoqinService {

}
