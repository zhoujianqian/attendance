package com.fzu.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fzu.service.StudentService;

/**
 * ���ܸ�Ҫ��UserController
 * 
 * @author psb
 * @time 2016.6.25
 */
@Controller
public class UserController {
	@Resource
	private StudentService userService;

	@RequestMapping("/find/{userId}") // ����·������

	public void getIndex(HttpServletRequest request, Model model, HttpServletResponse response) {

		// int userId = Integer.parseInt(request.getParameter("id"));
		// String pwd = request.getParameter("password");
		// System.out.println(userId);
		// ModelAndView mav = new ModelAndView("index");
		// JSONObject jSONObject = new JSONObject();
		// Stduent user = userService.selectUserById(userId);
		// System.out.println(user);
		// if (user != null) {
		// jSONObject.put("success", true);
		// } else {
		// jSONObject.put("success", false);
		// }
		// // mav.addObject("user", user);
		// //
		// System.out.println(user.getUserName()+"***********************************");
		//
		// // ����ҳ�治����
		// response.setHeader("Pragma", "No-cache");
		// response.setHeader("Cache-Control", "no-cache");
		// response.setCharacterEncoding("UTF-8");
		// PrintWriter out = null;
		// try {
		// out = response.getWriter();
		// out.print(jSONObject.toString());
		// out.flush();
		// out.close();
		// } catch (IOException e) {
		// e.printStackTrace();
		// }
		//
		// // return mav;
	}
}
