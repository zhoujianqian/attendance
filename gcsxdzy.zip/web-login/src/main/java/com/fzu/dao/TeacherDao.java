package com.fzu.dao;

import java.util.List;

import com.fzu.model.Teacher;

/**
 * ���ܸ�Ҫ��Teacher��DAO��
 * 
 * @author psb
 * @time 2016.6.25
 */
public interface TeacherDao {

	public Teacher selectUserById(String tId);

	public Teacher insert(String id, String name, String pwd, String tsex, String tphone, String tclass, String classID,
			String school);

	public Teacher update(String id, String tclass);

	public Teacher delete(String id);

	public List<Teacher> selectallteacher();
}
