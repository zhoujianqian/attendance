package com.fzu.dao;

import com.fzu.model.Leave;

/**
 * ���ܸ�Ҫ����ѧ�ƻ�DAO��
 * 
 * @author psb
 * @time 2016.6.25
 */
public interface ScheduleDao {

	public Leave selectById(String cno);

	// public Leave insert(Student );

	public Leave update(String cno, String cname);
}
