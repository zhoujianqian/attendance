package com.fzu.dao;

import java.util.List;

import com.fzu.model.Student;

/**
 * ���ܸ�Ҫ��Student��DAO��
 * 
 * @author psb
 * @time 2016.6.25
 */
public interface StudentDao {

	public Student selectUserById(String userId);

	public void insert(Student student);

	public Student update(String id, String phone);

	public Student delete(String id);

	public List<Student> selectallstudent();

	public List<Student> studentjoinclass();

	public List<Student> selectgenjuclassId(String classId);

}
