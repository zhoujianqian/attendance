package com.fzu.dao;

import java.sql.Date;

import com.fzu.model.KaoQin;

/**
 * ���ܸ�Ҫ�����ڵ�DAO��
 * 
 * @author psb
 * @time 2016.6.25
 */
public interface KaoQinDao {

	public KaoQin selectById(int kid);

	public KaoQin insert(int classId, String sId, String sname, String cname, String avalue, String caddress,
			Date ctime);
}
