package com.fzu.test;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.fzu.model.Teacher;
import com.fzu.service.TeacherService;

/**
 * ���ܸ�Ҫ��TeacherService��Ԫ����
 * 
 * @author psb
 * @time 2016.6.25
 */
public class TeacherServiceTest extends SpringTestCase {
	@Autowired
	private TeacherService teacherService;
	private Teacher teacher;
	private List<Teacher> allteacher = new ArrayList<Teacher>();
	Logger logger = Logger.getLogger(TeacherServiceTest.class);

	// // ��ʦ������ɾ�Ĳ�
	// // ��
	// @Test
	// public void selectteacherByIdTest() {
	//
	// teacher = teacherService.selectUserById("093701");
	// logger.debug("���ҽ��" + teacher.getTname());
	// }

	// �������н�ʦ
	@Test
	public void selectall() {
		allteacher = teacherService.selectall();
		System.out.println("����" + allteacher.size() + "����¼");
		System.out.println("��һ����¼��:" + allteacher.get(0).getTname());
	}

	// // ��
	// @Test
	// public void insertTest() {
	// teacher = teacherService.register("093713", "�ܽ�ٻ", "123456", "Ů",
	// "01234567890", "08", "1", "���ݴ�ѧ");
	// logger.debug("������" + teacher.getTname());
	// }
	//
	// // ɾ
	// @Test
	// public void deleteTest() {
	// teacher = teacherService.delete("1603010");
	// }
	//
	// // ��
	// @Test
	// public void updateTest() {
	// teacher = teacherService.update("1603011", "18888888888");
	// logger.debug("�޸Ľ��" + teacher.getTname());
	//
	// }
}
