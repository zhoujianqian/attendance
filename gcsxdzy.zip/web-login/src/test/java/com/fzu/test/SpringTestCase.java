package com.fzu.test;

import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * ���ܸ�Ҫ��
 * 
 * @author psb
 * @time 2016.6.25
 */
// ָ��beanע��������ļ�
@ContextConfiguration(locations = { "classpath:application.xml" })
// ʹ�ñ�׼��JUnit @RunWithע��������JUnitʹ��Spring TestRunner
@RunWith(SpringJUnit4ClassRunner.class)
public abstract class SpringTestCase extends AbstractJUnit4SpringContextTests {
	protected Logger logger = LoggerFactory.getLogger(getClass());
}
