/*==============================================================*/
/* DBMS name:      Sybase SQL Anywhere 11                       */
/* Created on:     2017/6/29/���� 15:57:28                        */
/*==============================================================*/


if exists(select 1 from sys.sysforeignkey where role='��ɫ') then
    alter table roleauth
       delete foreign key ��ɫ
end if;

if exists(select 1 from sys.sysforeignkey where role='Ȩ��') then
    alter table roleauth
       delete foreign key Ȩ��
end if;

if exists(select 1 from sys.sysforeignkey where role='���') then
    alter table student
       delete foreign key ���
end if;

if exists(select 1 from sys.sysforeignkey where role='�༶') then
    alter table student
       delete foreign key �༶
end if;

if exists(select 1 from sys.sysforeignkey where role='����') then
    alter table student
       delete foreign key ����
end if;

if exists(select 1 from sys.sysforeignkey where role='��ѧ�ƻ�') then
    alter table teacher
       delete foreign key ��ѧ�ƻ�
end if;

if exists(select 1 from sys.sysforeignkey where role='�м��') then
    alter table userrole
       delete foreign key �м��
end if;

if exists(
   select 1 from sys.systable 
   where table_name='admin'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table admin
end if;

if exists(
   select 1 from sys.systable 
   where table_name='auth'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table auth
end if;

if exists(
   select 1 from sys.systable 
   where table_name='classinfo'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table classinfo
end if;

if exists(
   select 1 from sys.systable 
   where table_name='kaoqin'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table kaoqin
end if;

if exists(
   select 1 from sys.systable 
   where table_name='leave'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table leave
end if;

if exists(
   select 1 from sys.systable 
   where table_name='role'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table role
end if;

if exists(
   select 1 from sys.systable 
   where table_name='roleauth'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table roleauth
end if;

if exists(
   select 1 from sys.systable 
   where table_name='schedule'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table schedule
end if;

if exists(
   select 1 from sys.systable 
   where table_name='student'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table student
end if;

if exists(
   select 1 from sys.systable 
   where table_name='teacher'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table teacher
end if;

if exists(
   select 1 from sys.systable 
   where table_name='userrole'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table userrole
end if;

/*==============================================================*/
/* Table: admin                                                 */
/*==============================================================*/
create table admin 
(
   userID               varchar                        not null,
   password             varchar                        null,
   userName             varchar                        null,
   school               varchar                        null,
   sex                  varchar                        null,
   phone                varchar                        null,
   constraint PK_ADMIN primary key clustered (userID)
);

/*==============================================================*/
/* Table: auth                                                  */
/*==============================================================*/
create table auth 
(
   authId               varchar                        not null,
   authName             varchar                        null,
   descript             varchar                        null,
   constraint PK_AUTH primary key clustered (authId)
);

/*==============================================================*/
/* Table: classinfo                                             */
/*==============================================================*/
create table classinfo 
(
   classID              varchar                        not null,
   cname                varchar                        null,
   classcap             int                            null,
   school               varchar                        null,
   college              varchar                        null,
   department           varchar                        null,
   profession           varchar                        null,
   constraint PK_CLASSINFO primary key clustered (classID)
);

/*==============================================================*/
/* Table: kaoqin                                                */
/*==============================================================*/
create table kaoqin 
(
   kID                  int                            not null,
   sID                  varchar                        null,
   sname                varchar                        null,
   cname                varchar                        null,
   avalue               varchar                        null,
   caddress             varchar                        null,
   ctime                datetime                       null,
   tname                varchar                        null,
   constraint PK_KAOQIN primary key clustered (kID)
);

/*==============================================================*/
/* Table: leave                                                 */
/*==============================================================*/
create table leave 
(
   vID                  int                            not null,
   sID                  varchar                        null,
   sname                varchar                        null,
   cname                varchar                        null,
   tname                varchar                        null,
   vreason              text                           null,
   vtime                datetime                       null,
   constraint PK_LEAVE primary key clustered (vID)
);

/*==============================================================*/
/* Table: role                                                  */
/*==============================================================*/
create table role 
(
   roleId               int                            not null,
   roleName             varchar                        null,
   descrip              varchar                        null,
   constraint PK_ROLE primary key clustered (roleId)
);

/*==============================================================*/
/* Table: roleauth                                              */
/*==============================================================*/
create table roleauth 
(
   roleId               int                            not null,
   aut_authId           varchar                        null,
   authId               int                            null,
   constraint PK_ROLEAUTH primary key clustered (roleId)
);

/*==============================================================*/
/* Table: schedule                                              */
/*==============================================================*/
create table schedule 
(
   cno                  varchar                        not null,
   tname                varchar                        null,
   cname                varchar                        null,
   pstime               datatime                       null,
   petime               datatime                       null,
   sstime               datatime                       null,
   setime               datatime                       null,
   totalxueshi          int                            null,
   clong                int                            null,
   constraint PK_SCHEDULE primary key clustered (cno)
);

/*==============================================================*/
/* Table: student                                               */
/*==============================================================*/
create table student 
(
   sID                  varchar                        not null,
   sname                varchar                        null,
   spwd                 varchar                        null,
   ssex                 varchar                        null,
   sphone               char                           null,
   school               varchar                        null,
   classID              varchar                        null,
   kID                  int                            null,
   vID                  int                            null,
   Column_8             varchar                        null,
   constraint PK_STUDENT primary key clustered (sID)
);

/*==============================================================*/
/* Table: teacher                                               */
/*==============================================================*/
create table teacher 
(
   tID                  varchar                        not null,
   cno                  varchar                        null,
   tname                varchar                        null,
   tpwd                 varchar                        null,
   tsex                 varchar                        null,
   tphone               char                           null,
   school               varchar                        null,
   constraint PK_TEACHER primary key clustered (tID)
);

/*==============================================================*/
/* Table: userrole                                              */
/*==============================================================*/
create table userrole 
(
   userId               varchar                        not null,
   roleId               int                            null,
   constraint PK_USERROLE primary key clustered (userId)
);

alter table roleauth
   add constraint ��ɫ foreign key (roleId)
      references role (roleId)
      on update restrict
      on delete restrict;

alter table roleauth
   add constraint Ȩ�� foreign key (aut_authId)
      references auth (authId)
      on update restrict
      on delete restrict;

alter table student
   add constraint ��� foreign key (vID)
      references leave (vID)
      on update restrict
      on delete restrict;

alter table student
   add constraint �༶ foreign key (classID)
      references classinfo (classID)
      on update restrict
      on delete restrict;

alter table student
   add constraint ���� foreign key (kID)
      references kaoqin (kID)
      on update restrict
      on delete restrict;

alter table teacher
   add constraint ��ѧ�ƻ� foreign key (cno)
      references schedule (cno)
      on update restrict
      on delete restrict;

alter table userrole
   add constraint �м�� foreign key (roleId)
      references roleauth (roleId)
      on update restrict
      on delete restrict;

