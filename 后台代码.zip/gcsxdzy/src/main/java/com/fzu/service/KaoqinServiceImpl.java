package com.fzu.service;

/**
 * @author psb 2017.5.28
 *
 */
public class KaoqinServiceImpl implements KaoqinService {

}
