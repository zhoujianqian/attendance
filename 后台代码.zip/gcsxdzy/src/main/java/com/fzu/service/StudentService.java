package com.fzu.service;

import java.util.List;

import com.fzu.model.Student;

/**
 * ���ܸ�Ҫ��StudentService�ӿ���
 * 
 * @author psb
 * @time 2017.5.25
 */
public interface StudentService {
	Student selectUserById(String userId);

	void register(String Id, String name, String pwd, String sex, String phone, String school, String classId);

	Student update(String id, String phone);

	Student delete(String id);

	List<Student> selectall();

	List<Student> classnameofstudent();

	List<Student> selectgenjuclassId(String classId);

}