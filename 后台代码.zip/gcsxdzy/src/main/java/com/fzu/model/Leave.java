package com.fzu.model;

import java.sql.Date;

/**
 * ���ӳ����
 * 
 * @author psb
 * @time 2017.5.28
 */
public class Leave {

	private int vID;
	private String sID;
	private String cname;
	private String vreason;
	private Date vtime;

	public int getvID() {
		return vID;
	}

	public void setvID(int vID) {
		this.vID = vID;
	}

	public String getsID() {
		return sID;
	}

	public void setsID(String sID) {
		this.sID = sID;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getVreason() {
		return vreason;
	}

	public void setVreason(String vreason) {
		this.vreason = vreason;
	}

	public Date getVtime() {
		return vtime;
	}

	public void setVtime(Date vtime) {
		this.vtime = vtime;
	}

}
