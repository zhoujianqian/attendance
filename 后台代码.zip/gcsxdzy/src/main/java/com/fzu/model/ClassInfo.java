package com.fzu.model;

/**
 * �༶ӳ����
 * 
 * @author psb
 * @time 2017.5.28
 */
public class ClassInfo {
	private String classID;
	private String cname;
	private int classcap;
	private String school;
	private String college;
	private String department;
	private String profession;

	public String getClassID() {
		return classID;
	}

	public void setClassID(String classID) {
		this.classID = classID;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public int getClasscap() {
		return classcap;
	}

	public void setClasscap(int classcap) {
		this.classcap = classcap;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

}
