package com.fzu.dao;

import java.util.List;

import com.fzu.model.ClassInfo;

/**
 * ���ܸ�Ҫ��Class��DAO��
 * 
 * @author psb
 * @time 2017.5.25
 */
public interface ClassDao {

	public ClassInfo selectClassById(String classId);

	public List<ClassInfo> selectallclass();

	public void insert(ClassInfo classinfo);

}
