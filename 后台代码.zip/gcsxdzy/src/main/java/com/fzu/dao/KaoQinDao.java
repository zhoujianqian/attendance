package com.fzu.dao;

import java.sql.Date;

import com.fzu.model.KaoQin;

/**
 * ���ܸ�Ҫ�����ڵ�DAO��
 * 
 * @author psb
 * @time 2017.5.28
 */
public interface KaoQinDao {

	public KaoQin selectById(int kid);

	public KaoQin insert(int classId, String sId, String sname, String cname, String avalue, String caddress,
			Date ctime);
}
