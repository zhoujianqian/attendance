package com.fzu.dao;

import java.sql.Date;

import com.fzu.model.Leave;

/**
 * ���ܸ�Ҫ����ٵ�DAO��
 * 
 * @author psb
 * @time 2017.5.25
 */
public interface LeaveDao {

	public Leave selectById(int vid);

	public Leave insert(int vid, String sId, String cname, String vreason, Date vtime);

}
