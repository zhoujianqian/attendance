package com.example.gcsxdzy;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class WelcomeActivity extends Activity implements OnClickListener {

	private Button login;
	private Button register;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.welcome);
		init();
	}
	
	private void init() {
		login = (Button) super.findViewById(R.id.btn_sign_in);
		register = (Button) super.findViewById(R.id.btn_sign_up);
		login.setOnClickListener(this);
		register.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		if (v == login) { // 跳转到登录界面
			// mLocationClient.start();
			Intent intent = new Intent(WelcomeActivity.this,LoginActivity.class);
			startActivity(intent);
			finish();
		} else if (v == register) { // 调转到注册界面
			Intent intent = new Intent(WelcomeActivity.this,RegisterActivity.class);
			startActivity(intent);
			finish();
		}
		
	}

}





