package com.fzu.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.fzu.model.Schedule;
import com.fzu.service.ScheduleService;

/**
 * @author psb 2016.5.30
 */
public class ScheduleServiceTest extends SpringTestCase {

	@Autowired
	private ScheduleService sheduleService;
	private Schedule shedule;

	Logger logger = Logger.getLogger(ScheduleServiceTest.class);

	// ��ѧ�ƻ�����ɾ�Ĳ�
	// ��
	@Test
	public Schedule selectSheduleBycnoTest(String cno) {
		if (cno != null) {
			shedule = sheduleService.selectBycno("10001");
			logger.debug("���ҽ��" + shedule.getTname());
		}
		return null;
	}

	// ��
	public void addSchedule() {
		String ps = "2017-03-08";
		String pe = "2017-06-20";
		String ss = "2017-03-15";
		String se = "2017-06-27";

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd:HH:mm");
		java.util.Date pstime = null;
		java.util.Date petime = null;
		java.util.Date sstime = null;
		java.util.Date setime = null;

		try {
			pstime = format.parse(ps);
			petime = format.parse(pe);
			sstime = format.parse(ss);
			setime = format.parse(se);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		sheduleService.addSchedule("100015", "����������", "093706", "����1��", new java.sql.Date(pstime.getTime()),
				new java.sql.Date(petime.getTime()), new java.sql.Date(sstime.getTime()),
				new java.sql.Date(setime.getTime()), 1, 2, "��2-203");

	}

}
