package com.fzu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fzu.dao.ClassDao;
import com.fzu.model.ClassInfo;

/**
 * ���ܸ�Ҫ��ClassInfo�ӿ���
 * 
 * @author psb
 * @time 2017.5.28
 */
@Service
public class ClassInfoServiceImpl implements ClassInfoService {

	@Autowired
	private ClassDao classdao;
	private ClassInfo classinfo;

	public ClassInfo selectById(String classId) {
		if (classId.length() > 0) {
			return classdao.selectClassById(classId);

		}
		return null;
	}

	public List<ClassInfo> selectall() {

		return classdao.selectallclass();
	}

	public void insert(String classId, String cname, int classcap, String school, String college, String department,
			String profession) {
		if (classId.length() > 0 && cname.length() > 0 && classcap > 0 && school.length() > 0 && college.length() > 0
				&& department.length() > 0 && profession.length() > 0) {

			classinfo = new ClassInfo();
			classinfo.setClassID(classId);
			classinfo.setCname(cname);
			classinfo.setClasscap(classcap);
			classinfo.setSchool(school);
			classinfo.setCollege(college);
			classinfo.setDepartment(department);
			classinfo.setProfession(profession);
			classdao.insert(classinfo);

		}

	}

}
