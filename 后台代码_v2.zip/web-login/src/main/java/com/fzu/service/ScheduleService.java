package com.fzu.service;

import java.sql.Date;

import com.fzu.model.Schedule;

/**
 * @author psb 2017.5.30
 *
 */
public interface ScheduleService {

	Schedule selectBycno(String cno);

	void addSchedule(String cno, String tname, String tid, String cname, Date pstime, Date petime, Date sstime,
			Date setime, int clong, int xueshi, String caddress);
}
