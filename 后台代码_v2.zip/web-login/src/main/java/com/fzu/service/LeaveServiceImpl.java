package com.fzu.service;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fzu.dao.LeaveDao;
import com.fzu.model.Leave;

/**
 * ���ܸ�Ҫ��Leave�ӿ�ʵ����
 * 
 * @author psb
 * @time 2017.5.28
 */
@Service
public class LeaveServiceImpl implements LeaveService {

	@Autowired
	private LeaveDao leavedao;
	private Leave leave;
	// private List<Leave> leave=new ArrayList<Leave>();

	public List<Leave> selectLeaveBysId(String sId) {
		if (sId.length() > 0) {
			return leavedao.selectLeaveBysId(sId);

		}
		return null;
	}

	public void insert(int vId, String sID, String sname, String cname, String tname, String vreason, Date vtime) {
		if (sID.length() > 0 && sname.length() > 0 && cname.length() > 0 && tname.length() > 0 && vreason.length() > 0
				&& vtime != null) {
			leave = new Leave();
			leave.setvID(vId);
			leave.setsID(sID);
			leave.setSname(sname);
			leave.setCname(cname);
			leave.setTname(tname);
			leave.setVreason(vreason);
			leave.setVtime(vtime);

			leavedao.insert(leave);

		}
	}

}
