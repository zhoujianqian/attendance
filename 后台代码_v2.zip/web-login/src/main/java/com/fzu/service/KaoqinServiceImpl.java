package com.fzu.service;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fzu.dao.KaoQinDao;
import com.fzu.model.KaoQin;

/**
 * @author psb 2017.5.28
 *
 */
@Service
public class KaoqinServiceImpl implements KaoqinService {

	@Autowired
	private KaoQinDao kaoqindao;
	private KaoQin kaoqin;

	public List<KaoQin> selectKaoqinById(int kId) {
		if (kId > 0) {

			return kaoqindao.selectKaoqinById(kId);
		}
		return null;
	}

	public void insert(int kId, String sID, String sname, String cname, int avalue, String caddress, Date ctime,
			String tname) {

		if (kId > 0 && sID != null && sname != null && cname != null && caddress != null && ctime != null
				&& tname != null) {
			kaoqin = new KaoQin();
			kaoqin.setkID(kId);
			kaoqin.setsId(sID);
			kaoqin.setSname(sname);
			kaoqin.setCname(cname);
			kaoqin.setAvalue(avalue);
			kaoqin.setCaddress(caddress);
			kaoqin.setCtime(ctime);
			kaoqin.setTname(tname);
			kaoqindao.insert(kaoqin);

		}

	}

}
