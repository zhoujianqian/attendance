package com.fzu.service;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fzu.dao.ScheduleDao;
import com.fzu.model.Schedule;

/**
 * @author psb 2017.5.30
 *
 */
@Service
public class ScheduleServiceImpl implements ScheduleService {

	@Autowired
	private ScheduleDao scheduledao;
	private Schedule schedule;

	public Schedule selectBycno(String cno) {
		if (cno.length() > 0) {
			return scheduledao.selectscheduleBycno(cno);
		}
		return null;
	}

	@Override
	public void addSchedule(String cno, String tname, String tid, String cname, Date pstime, Date petime, Date sstime,
			Date setime, int clong, int xueshi, String caddress) {
		if (cno != null && tname != null) {
			schedule = new Schedule();
			schedule.setCno(cno);
			schedule.setTname(tname);
			schedule.setTid(tid);
			schedule.setCname(cname);
			schedule.setPstime(pstime);
			schedule.setPetime(petime);
			schedule.setSstime(sstime);
			schedule.setSetime(setime);
			schedule.setClong(clong);
			schedule.setXueshi(xueshi);
			schedule.setCaddress(caddress);
			scheduledao.addschedule(schedule);
		}

	}

}
