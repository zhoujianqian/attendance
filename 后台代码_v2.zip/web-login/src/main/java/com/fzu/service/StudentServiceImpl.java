package com.fzu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fzu.dao.StudentDao;
import com.fzu.model.Student;

/**
 * ���ܸ�Ҫ��StudentServiceʵ����
 * 
 * @author psb
 * @time 2017��5��25��
 */
@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentDao studentdao;
	private Student student;

	public Student selectUserById(String userId) {
		if (userId.length() > 0) {
			return studentdao.selectUserById(userId);
		}
		return null;
	}

	// ���ݰ༶�Ų�����ѧ��
	public List<Student> selectgenjuclassId(String classId) {

		if (classId != null && classId.length() > 0) {
			System.out.println("classId=" + classId);
			return studentdao.selectgenjuclassId(classId);
		}
		return null;
	}

	public List<Student> selectall() {

		return studentdao.selectallstudent();
	}

	public List<Student> classnameofstudent() {

		return studentdao.studentjoinclass();
	}

	public void register(String Id, String name, String pwd, String sex, String phone, String school, String classId) {
		if (Id.length() > 0 && pwd.length() > 0 && name.length() > 0 && sex.length() > 0 && phone.length() > 0
				&& school.length() > 0 && classId.length() > 0) {
			student = new Student();
			student.setsID(Id);
			student.setSname(name);
			student.setSpwd(pwd);
			student.setSsex(sex);
			student.setSphone(phone);
			student.setSchool(school);
			student.setClassID(classId);
			studentdao.insert(student);
		}

	}

	public Student update(String Id, String phone) {
		if (Id.length() > 0 && phone.length() > 0) {
			return studentdao.update(Id, phone);
		}
		return null;
	}

	public Student delete(String Id) {
		if (Id.length() > 0) {
			return studentdao.delete(Id);
		}
		return null;
	}

}
