package com.fzu.model;

/**
 * Teacherӳ����
 * 
 * @author psb
 * @time 2017.5.25
 */
public class Teacher {

	private String tID;
	private String tname;
	private String tpwd;
	private String tsex;
	private String tphone;
	// private String tclass;
	// private String classID;
	private String school;

	public String gettID() {
		return tID;
	}

	public void settID(String tID) {
		this.tID = tID;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getTpwd() {
		return tpwd;
	}

	public void setTpwd(String tpwd) {
		this.tpwd = tpwd;
	}

	public String getTsex() {
		return tsex;
	}

	public void setTsex(String tsex) {
		this.tsex = tsex;
	}

	// public String getTclass() {
	// return tclass;
	// }
	//
	// public void setTclass(String tclass) {
	// this.tclass = tclass;
	// }

	public String getTphone() {
		return tphone;
	}

	public void setTphone(String tphone) {
		this.tphone = tphone;
	}

	// public String getClassID() {
	// return classID;
	// }
	//
	// public void setClassID(String classID) {
	// this.classID = classID;
	// }

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

}
