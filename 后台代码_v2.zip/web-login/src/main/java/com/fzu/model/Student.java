package com.fzu.model;

/**
 * Studentӳ����
 * 
 * @author psb
 * @time 2017.5.25
 */
public class Student {
	private String sID;
	private String sname;
	private String spwd;
	private String ssex;
	private String sphone;
	private String school;
	private String classID;

	// ����༶����
	private ClassInfo classinfo;

	public String getsID() {
		return sID;
	}

	public void setsID(String sID) {
		this.sID = sID;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSpwd() {
		return spwd;
	}

	public void setSpwd(String spwd) {
		this.spwd = spwd;
	}

	public String getSsex() {
		return ssex;
	}

	public void setSsex(String ssex) {
		this.ssex = ssex;
	}

	public String getSphone() {
		return sphone;
	}

	public void setSphone(String sphone) {
		this.sphone = sphone;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getClassID() {
		return classID;
	}

	public void setClassID(String classID) {
		this.classID = classID;
	}

	public ClassInfo getClassinfo() {
		return classinfo;
	}

	public void setClassinfo(ClassInfo classinfo) {
		this.classinfo = classinfo;
	}

}
