package com.fzu.model;

import java.sql.Date;

/**
 * ����ӳ����
 * 
 * @author psb
 * @time 2017.5.28
 */
public class KaoQin {

	private int kID;
	private String sId;
	private String sname;
	private String cname;
	private int avalue;
	private String caddress;
	private Date ctime;
	private String tname;

	public int getkID() {
		return kID;
	}

	public void setkID(int kID) {
		this.kID = kID;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getsId() {
		return sId;
	}

	public void setsId(String sId) {
		this.sId = sId;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public int getAvalue() {
		return avalue;
	}

	public void setAvalue(int avalue) {
		this.avalue = avalue;
	}

	public String getCaddress() {
		return caddress;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}

	public Date getCtime() {
		return ctime;
	}

	public void setCtime(Date ctime) {
		this.ctime = ctime;
	}

}
