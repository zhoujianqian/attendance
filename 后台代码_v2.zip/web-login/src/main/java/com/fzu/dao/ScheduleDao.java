package com.fzu.dao;

import com.fzu.model.Leave;
import com.fzu.model.Schedule;

/**
 * ���ܸ�Ҫ����ѧ�ƻ�DAO��
 * 
 * @author psb
 * @time 2017.5.25
 */
public interface ScheduleDao {

	public Leave update(String cno);

	public Schedule selectscheduleBycno(String cno);

	public void addschedule(Schedule schedule);
}
