package com.fzu.dao;

import java.util.List;

import com.fzu.model.KaoQin;

/**
 * ���ܸ�Ҫ�����ڵ�DAO��
 * 
 * @author psb
 * @time 2017.5.28
 */
public interface KaoQinDao {

	public List<KaoQin> selectKaoqinById(Integer kId);

	public void insert(KaoQin kaoqin);
}
