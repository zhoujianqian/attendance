package com.fzu.dao;

import java.util.List;

import com.fzu.model.Leave;

/**
 * ���ܸ�Ҫ����ٵ�DAO��
 * 
 * @author psb
 * @time 2017.5.25
 */
public interface LeaveDao {

	public List<Leave> selectLeaveBysId(String sId);

	public void insert(Leave leave);

}
